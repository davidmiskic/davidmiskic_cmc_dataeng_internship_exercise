def moto():
    return "Coding for our patients."